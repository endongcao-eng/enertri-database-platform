# Q355 GMAW 温度场示例

目标软件：ANSYS MAPDL / PyMAPDL

本目录由 EnerTri 生成，用于焊接过程数值仿真的前处理和批处理集成。

## 使用原则

1. 在真实求解前核对单位制、材料热物性、热源模型、边界条件、网格独立性与时间步独立性。
2. 用热循环、熔池形貌、变形或残余应力实验数据进行标定和验证。
3. 商业软件许可证、可执行文件路径和命令行参数由部署管理员配置。
4. 自动生成内容是可编辑模板，不替代 CAE 工程师审查。

## 输入参数

```json
{
  "process": "GMAW",
  "current_a": 220,
  "voltage_v": 24,
  "efficiency": 0.8,
  "travel_speed_mm_s": 5,
  "length_mm": 100,
  "width_mm": 50,
  "thickness_mm": 8,
  "mesh_size_mm": 2,
  "heat_source_model": "Goldak double ellipsoid"
}
```
